==================================================
HW #3: Dungeons & Dragons
Ben-Gurion University - Spring 2026
==================================================

BUILD / RUN
-----------
java -jar hw3.jar <path to levels directory>

The directory must contain level1.txt, level2.txt, ... files.

CONTROLS
--------
w/a/s/d - Move up/left/down/right
e       - Cast special ability
q       - Do nothing (skip turn)

BONUS TASKS IMPLEMENTED
-----------------------
[X] Add new player class: Hunter (Ygritte: 220/30/2, range 6)
    - Resource: arrows (initial = 10 * level)
    - Special ability: Shoot - hits closest enemy in range for ATK damage
    - Refills 'level' arrows every 10 game ticks

[X] HeroicUnit interface + Boss enemy class
    - HeroicUnit interface declares castAbility()
    - All Player subclasses (Warrior, Mage, Rogue, Hunter) implement it
    - Boss extends Monster, also implements HeroicUnit
    - The Mountain ('M'), Queen Cersei ('C'), Night's King ('K') are bosses
    - Boss's Shoebodybop ability shoots player if in vision range

DESIGN OVERVIEW
---------------
Two separate hierarchies as required:
  - Cell hierarchy:    Cell -> {Wall, Floor}
  - Occupant hierarchy: Occupant -> Unit -> {Player, Enemy}
                                    Player -> {Warrior, Mage, Rogue, Hunter}
                                    Enemy  -> Monster -> Boss
                                              Trap

Visitor pattern is used at TWO levels for every unit movement, with NO
instanceof or casting:
  - Level 1 (CellVisitor):     visits Wall or Floor
  - Level 2 (OccupantVisitor): visits Player or Enemy on a Floor cell

GameBoard wraps an internal Cell[][] array and exposes only:
  - getCell(Position)
  - getOccupant(Position)
  - setOccupant(Position, Occupant)
Nothing outside GameBoard touches the raw array.

The Observer / Callback pattern (MessageCallback interface) decouples
business logic from the UI. The CLI class is the only class that calls
System.out.println - all other classes send messages through the callback.

Position is an immutable value object holding (x, y) with Euclidean
distance via range(other).

Health and ability-resource updates use bounded setters (setHealthAmount
clamps to [0, healthPool], mana clamps to manaPool, energy clamps to 100).

OUTPUT FORMAT NOTES
-------------------
Field separators in unit descriptions use TWO tab characters ("\t\t")
to produce a consistent column layout (tab stops every 8 chars => fields
align at multiples of 24).

The Avenger's Shield "healing for X" message reports the FORMULA amount
(10 * defense), not the actual delta after capping at health pool, matching
the reference behavior.

WARRIOR LEVEL-UP NOTE
---------------------
Implemented strictly per the spec:
  Player base: +10*level Health, +4*level Attack, +1*level Defense
  Warrior extra: +5*level Health, +2*level Attack, +1*level Defense
This produces totals of +15*level Health, +6*level Attack, +2*level Defense
at each level up. The reference game logs sometimes display +3*level Defense
(e.g., +6 at level 2 instead of +4); this appears to be a discrepancy in
the reference implementation - the spec text is followed exactly here.

TESTING
-------
GameTest provides 24 self-contained unit tests (no JUnit dependency) covering
Position, combat, leveling, abilities, traps, board logic, health bounds, and
movement edge cases. Run via:
  javac -cp out/main -d out/test src/test/java/game/GameTest.java
  java -cp out/main:out/test game.GameTest

SUBMITTED FILES
---------------
src/      - source code (main + test)
out/      - compiled classes
hw3.jar   - executable jar (built from out/main)
hw3.pdf   - UML class diagram
README.txt - this file

NOTE: Submitted as a SINGLE-STUDENT submission.
